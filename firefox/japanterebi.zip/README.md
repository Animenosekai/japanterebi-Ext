# CORS
 Something which unblocks CORS for Japan Terebi
